drop database student;
create database student;